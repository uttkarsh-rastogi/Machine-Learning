import os
import json
import urllib.parse
import boto3
import logging
from pprint import pprint
from botocore.exceptions import ClientError
import requests
from datetime import datetime

from rekognition_objects import (
    RekognitionFace, RekognitionCelebrity, RekognitionLabel,
    RekognitionModerationLabel, RekognitionText, show_bounding_boxes, show_polygons)

s3 = boto3.client('s3')

def lambda_handler(event, context):
    # Get the object from the event and show its content type
    #topic_arn = os.environ['topic_arn']
    #bucket_name = event['Records'][0]['s3']['bucket']['name']
    #key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    bucket_name = event['bucket_name']
    key = event['file_name']
    processed_bucket = event['processed_bucket']
    region = event['region']
    f_name = key.split('/')[1]
    sub_dir = key.split('/')[0]
    sub_name = key.split('/')[-1]
    #final_name = key.split('/')
    #final_name1 = "".join(final_name)
    #print(final_name1)
    #print(final_name)

    hashed_filename = str(datetime.now()).replace('-','').replace(' ','').replace(':','').replace('.','')
    #hashed_filename = hashed_key
    logger = logging.getLogger(__name__)
    # kinesis_client = boto3.client('kinesis',region)
    rekognition_client = boto3.client('rekognition', region)
    #s3_client = boto3.client('s3', region)
    #sns = boto3.client('sns', region)
    #stream_name = os.environ['main_stream']
    #stream_name_meta = os.environ['main_stream_meta']
    #flag = 1
    
    def Merge(dict1, dict2):
       return(dict2.update(dict1))

    """
    def move_s3_object_on_success(source_bucket,source_key,dest_bucket,dest_key):
        s3 = boto3.resource('s3')
        copy_source = {
             'Bucket': source_bucket,
             'Key': source_key
             }
        s3.meta.client.copy(copy_source, dest_bucket, dest_key)
     
    def delete_s3_object(source_bucket,source_key):
        response = s3_client.delete_object(
            Bucket=source_bucket,
            Key=source_key
        )
    
    def kds_put_record(json_data,stream_name):
        stream = KinesisStream(kinesis_client)
        stream.name = stream_name
        partition_key = 'test-key'
        print(stream.put_record(json_data,stream.name))
    
    def publish_message_on_error(message):
    # Publish a simple message to the specified SNS topic
        response = sns.publish(
           TopicArn=topic_arn,
           Message=message
        )
    """

    try:
        class RekognitionImage:
            def __init__(self, image, image_name, rekognition_client):
                self.image = image
                self.image_name = image_name
                self.rekognition_client = rekognition_client

            @classmethod
            def from_file(cls, image_file_name, rekognition_client, image_name=None):
                with open(image_file_name, 'rb') as img_file:
                    image = {'Bytes': img_file.read()}
                    name = image_file_name if image_name is None else image_name
                    return cls(image, name, rekognition_client)

            @classmethod
            def from_bucket(cls, s3_object, rekognition_client):
                image = {'S3Object': {'Bucket': s3_object.bucket_name, 'Name': s3_object.key}}
                return cls(image, s3_object.key, rekognition_client)

            def detect_faces(self):
                try:
                    li1 = []
                    response = self.rekognition_client.detect_faces(
                    Image=self.image, Attributes=['ALL'])
                    faces = [RekognitionFace(face) for face in response['FaceDetails']]
                    def get_dict_items(_data):
                        dict3 = {"Hashed_value": hashed_filename}
                        dict1 = {"Filename": key.replace('\u200b','')}
                        X = [ data for data in response['FaceDetails']]
                        object_dict = {"item1": "Emotions","item2": "AgeRange","item3": "Gender","item4": "Smile","item5": "Sunglasses", "item6": "Eyeglasses","item7": "Beard", "item8": "Mustache"}
                        for item in object_dict.values():
                          if item == "AgeRange":
                             dict2 = {}
                             confidence_age_1 = X[_data][item]['Low']
                             confidence_age_2 = X[_data][item]['High']
                             dict2.update({"Object_type": item})
                             dict2.update({"Confidence": "NA"})
                             dict2.update({"Object_parameter": confidence_age_1+'-'+confidence_age_2})
                             Merge(dict1,dict2)
                             Merge(dict2,dict3)
                             return dict3
                          elif item == 'Emotions':
                             dict2 = {}
                             dict3 = {"Hashed_value": hashed_filename}
                             for i in range(0, len(X[_data]['Emotions'])):
                                 emotion_type = str(X[_data]['Emotions'][i]['Type'])
                                 emotion_confidence = X[_data]['Emotions'][i]['Confidence']
                                 dict2.update({"Object_type": emotion_type})
                                 dict2.update({"Object_parameter": "NA"})
                                 dict2.update({"Confidence": emotion_confidence})
                                 Merge(dict1,dict2)
                                 Merge(dict2,dict3)
                                 dict3.update({"File_Type": "Image"})
                                 dict3.update({"Analysis_Type": item+'_in_Image'})
                                 return dict3
                          elif item == 'Gender':
                             dict2 = {}
                             dict3 = {"Hashed_value": hashed_filename}
                             confidence = X[_data][item]['Confidence']
                             _type = str(X[_data][item]['Value'])
                             dict2.update({"Object_type": item+'_'+_type})
                             dict2.update({"Object_parameter": "NA"})
                             dict2.update({"Confidence": confidence})
                             Merge(dict1,dict2)
                             Merge(dict2,dict3)
                             dict3.update({"File_Type": "Image"})
                             dict3.update({"Analysis_Type": item+'_in_Image'})
                             return dict3
                          else:
                            dict2 = {}
                            dict3 = {"Hashed_value": hashed_filename}
                            confidence = X[_data][item]['Confidence']
                            dict2.update({"Object_type": item})
                            dict2.update({"Object_parameter": X[_data][item]['Value']})
                            dict2.update({"Confidence": confidence})
                            Merge(dict1,dict2)
                            Merge(dict2,dict3)
                            dict3.update({"File_Type": "Image"})
                            dict3.update({"Analysis_Type": item+'_in_Image'})
                            return dict3
                    if len(faces) != 0:
                      for _data in range(len(faces)):
                        #print(get_dict_items(_data))
                        li1.append(get_dict_items(_data))
                        #kds_put_record(get_dict_items(_data),stream_name)
                        #dict3 = {"Hashed_value": hashed_filename}
                        #dict1 = {"Filename": key.split('/')[1]}
                        #dict1 = {"Filename": key.replace('\u200b','')}
                        #dict2 = {}
                    print(li1)
                    return li1
                except ClientError as e:
                    logger.exception("Couldn't detect faces in %s.", self.image_name)
                    #publish_message_on_error(e)
                    raise
                          
            def detect_labels(self):
                try:
                    response = self.rekognition_client.detect_labels(
                            Image=self.image)
                    labels = [RekognitionLabel(label) for label in response['Labels']]
                    li2 = []
                    dict2 = {}
                    dict3 = {"Hashed_value": hashed_filename}
                    #dict1 = {"Filename": key.split('/')[1]}
                    dict1 = {"Filename": key.replace('\u200b','')}
                    if len(labels) != 0:
                        for sub in response['Labels']:
                            label_name = sub['Name']
                            dict2.update({"Object_type": sub['Name']})
                            dict2.update({"Object_parameter": "NA"})
                            dict2.update({"Confidence": sub['Confidence']})
                            Merge(dict1,dict2)
                            Merge(dict2,dict3)
                            dict3.update({"File_Type": "Image"})
                            dict3.update({"Analysis_Type": "Labels_in_Image"})
                            li2.append(dict3)
                            #kds_put_record(dict3,stream_name)
                            #dict3 = {"Hashed_value": hashed_filename}
                            #dict1 = {"Filename": key.split('/')[1]}
                            #dict1 = {"Filename": key.replace('\u200b','')}
                    print(li2)
                    return li2
                except ClientError as e:
                    logger.info("Couldn't detect labels in %s.", self.image_name)
                    #publish_message_on_error(e)
                    raise                    

            def detect_moderation_labels(self):
                try:
                    response = self.rekognition_client.detect_moderation_labels(
                    Image=self.image)
                    labels = [RekognitionModerationLabel(label) for label in response['ModerationLabels']]
                    li3 = []
                    def get_dict_items(_data):
                       dict3 = {"Hashed_value": hashed_filename}
                       dict1 = {"Filename": key.replace('\u200b','')}
                       #dict1 = {"Filename": key.split('/')[1]}
                       dict2 = {}
                       X = [ data for data in response['ModerationLabels']]
                       label_name = X[_data]['Name']
                       confidence = X[_data]['Confidence']
                       parents =  X[_data]['ParentName']
                       if parents != ' ':
                          dict2.update({"Object_type": label_name+'_'+parents})
                       else:
                          dict2.update({"Object_type": label_name})
                          dict2.update({"Object_parameter": label_name})
                          dict2.update({"Confidence": confidence})
                          Merge(dict1,dict2)
                          Merge(dict2,dict3)
                          dict3.update({"File_Type": "Image"})
                          dict3.update({"Analysis_Type": "Moderation_in_Image"})
                          return dict3
                    if len(labels) != 0:
                       for _data in range(0,len(labels)):
                         #kds_put_record(get_dict_items(_data),stream_name)
                         li3.append(get_dict_items(_data))
                         #dict3 = {"Hashed_value": hashed_filename}
                         #dict1 = {"Filename": key.split('/')[1]}
                    print(li3)
                    return li3
                except ClientError as e:
                    logger.exception(
                        "Couldn't detect moderation labels in %s.", self.image_name)
                    #publish_message_on_error(e)
                    raise   
                    
            def detect_text(self):
                try:
                    dict2 = {}
                    dict3 = {"Hashed_value": hashed_filename}
                    #dict1 = {"Filename": key.split('/')[1]}
                    dict1 = {"Filename": key.replace('\u200b','')}
                    response = self.rekognition_client.detect_text(Image=self.image)
                    texts = [RekognitionText(text) for text in response['TextDetections']]
                    li4 = []
                    if len(texts) != 0:
                        for sub in response['TextDetections']:
                          text_type = sub['Type']
                          dict2.update({"Object_type": sub['DetectedText']+'_'+text_type})
                          dict2.update({"Object_parameter": "NA"})
                          dict2.update({"Confidence": sub['Confidence']})
                          Merge(dict1,dict2)
                          Merge(dict2,dict3)
                          dict3.update({"File_Type": "Image"})
                          dict3.update({"Analysis_Type": "Text_in_Image"})
                          li4.append(dict3)
                          #kds_put_record(dict3,stream_name)
                          #dict3 = {"Hashed_value": hashed_filename}
                          #dict1 = {"Filename": key.split('/')[1]}
                          #dict1 = {"Filename": key.replace('\u200b','')}
                    print(li4)
                    return li4
                except ClientError as e:
                    logger.exception("Couldn't detect text in %s.", self.image_name)
                    #publish_message_on_error(e)
                    raise

            def recognize_celebrities(self):
                try:
                    response = self.rekognition_client.recognize_celebrities(
                        Image=self.image)
                    celebrities = [RekognitionCelebrity(celeb)
                                for celeb in response['CelebrityFaces']]
                    other_faces = [RekognitionFace(face)
                                for face in response['UnrecognizedFaces']]
                    li5 = []
                    def get_dict_items(_data):
                        dict2 = {}
                        dict3 = {"Hashed_value": hashed_filename}
                        #dict1 = {"Filename": key.split('/')[1]}
                        dict1 = {"Filename": key.replace('\u200b','')}
                        X = [ data for data in response['CelebrityFaces']]
                        celeb_confidence = X[_data]['Face']['Confidence']
                        celeb_name = X[_data]['Name']
                        dict2.update({"Object_type": "Celebrity"+'_'+celeb_name})
                        dict2.update({"Object_parameter": "NA"})
                        dict2.update({"Confidence": celeb_confidence})
                        Merge(dict1,dict2)
                        Merge(dict2,dict3)
                        dict3.update({"File_Type": "Image"})
                        dict3.update({"Analysis_Type": "Celebrities_in_Image"})
                        return dict3
                    if len(celebrities) != 0:
                        for _data in range(0,len(celebrities)):
                            #kds_put_record(get_dict_items(_data),stream_name)
                            li5.append(get_dict_items(_data))
                            #dict3 = {"Hashed_value": hashed_filename}
                            #dict1 = {"Filename": key.split('/')[1]}
                            #dict2 = {}
                    print(li5)
                    return li5
                except ClientError as e:
                    logger.exception("Couldn't detect celebrities in %s.", self.image_name)
                    #publish_message_on_error(e)
                    raise        
                    
            def recognize_ppe(self):
                try:
                    dict2 = {}
                    dict3 = {"Hashed_value": hashed_filename}
                    #dict1 = {"Filename": key.split('/')[1]}
                    dict1 = {"Filename": key.replace('\u200b','')}
                    li6 = []
                    response = self.rekognition_client.detect_protective_equipment(
                       Image=self.image)
                    if len(response['Persons']) != 0:
                        for items in response['Persons']:
                         for newitems in items['BodyParts']:
                          item1 = newitems['Name']
                          item2 = newitems['Confidence']
                          confidence = {"Confidence": item2}
                          for data in newitems['EquipmentDetections']:
                            confidence_percentage = data['CoversBodyPart']['Confidence']
                            confidence_value =  data['CoversBodyPart']['Value']
                            object_type = {"Object_type": item1+'_COVER'}
                            object_parameter = {"Object_parameter": confidence_value}
                            confidence =  {"Confidence": confidence_percentage}
                            dict2.update(object_type)
                            dict2.update(object_parameter)
                            dict2.update(confidence)
                            Merge(dict1,dict2)
                            Merge(dict2,dict3)
                            dict3.update({"File_Type": "Image"})
                            dict3.update({"Analysis_Type": "PPE_in_Image"})
                            li6.append(dict3)
                            #kds_put_record(dict3,stream_name)
                            #dict3 = {"Hashed_value": hashed_filename}
                            #dict1 = {"Filename": key.split('/')[1]}
                            #dict1 = {"Filename": key.replace('\u200b','')}
                    print(li6)
                    return li6
                except ClientError as e:
                    logger.exception("Couldn't detect ppe in %s.", self.image_name)
                    #publish_message_on_error(e)
                    raise
            """
            def meta_data_creation(status, sub_buck, fail_r):
                file_format = key.split('.')[1]
                time = str(datetime.now())
                file_uri = 's3://'+processed_bucket+'/'+sub_buck+'/'+key
                #file_uri = 's3://'+processed_bucket+'/'+'processed'+'/'+key
                project_relationship = os.environ['project_name']
                Project_id = os.environ['project_id']
                object_tagging = []
                meta_data_frame = {"Hashed_value": hashed_filename, "Filename": key.split('/')[1], "File_format": file_format, "Timestamp": time, "File_uri": file_uri, "Execution_status": status,  "Object_tagging": object_tagging, "Failure_reason": fail_r}
                #kds_put_record(meta_data_frame,stream_name_meta)
            """
        print('-'*88)
        print("Welcome to the Amazon Rekognition image detection demo!")
        print('-'*88)

        logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
        street_scene_file_name = boto3.resource('s3').Object(bucket_name, key)
        celebrity_file_name = boto3.resource('s3').Object(bucket_name, key)
        one_girl_url = boto3.resource('s3').Object(bucket_name, key)
        three_girls_url = boto3.resource('s3').Object(bucket_name, key)
        swimwear_object = boto3.resource('s3').Object(bucket_name, key)
        book_file_name = boto3.resource('s3').Object(bucket_name, key)
        ppe_file_name = boto3.resource('s3').Object(bucket_name, key)

        ppe_image = RekognitionImage.from_bucket(ppe_file_name, rekognition_client)
        print(f"Detecting PPE in {ppe_image.image_name}...")
        lis1 = ppe_image.recognize_ppe()


        street_scene_image = RekognitionImage.from_bucket(
            street_scene_file_name, rekognition_client)
        print(f"Detecting faces in {key}...")
        lis2 = street_scene_image.detect_faces()

        print(f"Detecting labels in {street_scene_image.image_name}...")
        lis3 = street_scene_image.detect_labels()

        celebrity_image = RekognitionImage.from_bucket(
          celebrity_file_name, rekognition_client)
        print(f"Detecting celebrities in {celebrity_image.image_name}...")
        lis4 = celebrity_image.recognize_celebrities()

        swimwear_image = RekognitionImage.from_bucket(swimwear_object, rekognition_client)
        print(f"Detecting suggestive content in {swimwear_object.key}...")
        lis5 = swimwear_image.detect_moderation_labels()

        book_image = RekognitionImage.from_bucket(book_file_name, rekognition_client)
        print(f"Detecting text in {book_image.image_name}...")
        lis6 = book_image.detect_text()

        print('-'*88)

        lisss = []
        lisss.extend(lis1)
        lisss.extend(lis2)
        lisss.extend(lis3)
        lisss.extend(lis4)
        lisss.extend(lis5)
        lisss.extend(lis6)

        print(lisss)

        file = json.dumps(lisss)
        #s3 = boto3.client('s3')
        s3.put_object(Body=json.dumps(lisss), Bucket= processed_bucket, Key = sub_dir + '/' + f_name + '/' + 'Files' + '/' + sub_name + '.json')
        print("Thanks for watching!")
        print('-'*88)
        vll = {"File_Name" : str(key.replace('\u200b','')),"Processed" : "Y","Analyzed" : "Y","Cause" : "","Func_Name" : "Img_Lambda"}
        s3.put_object(Body=json.dumps(vll), Bucket= processed_bucket, Key = sub_dir + '/' + f_name + '/' + 'Logs' + '/' +'log_'+ sub_name + '.json')
        #RekognitionImage.meta_data_creation('Successful','processed', '')
        #flag = 0
    except Exception as e:
        print("Main Block Exception -> ",e)
        vll = {"File_Name" : str(key.replace('\u200b','')),"Processed" : "N","Analyzed" : "N","Cause" : "Not Processed","Func_Name" : "Img_Lambda"}
        s3.put_object(Body=json.dumps(vll), Bucket= processed_bucket, Key = sub_dir + '/' + f_name + '/' + 'Logs' + '/' +'log_'+ sub_name + '.json')
        #RekognitionImage.meta_data_creation('Error','error', str(e.__class__).replace("'",""))
        #flag = 1
        #publish_message_on_error(e)
    """
    finally:
        if(flag==1):
            destfile = 'error'+'/'+key
            move_s3_object_on_success(bucket_name,key,processed_bucket,destfile)
        elif(flag==0):
            destfile = 'processed'+'/'+key
            move_s3_object_on_success(bucket_name,key,processed_bucket,destfile)
        #delete_s3_object(bucket_name,key)
        #print("Thanks for watching!")
        print('-'*88)
    """
"""
def lambda_handler(event, context):
    try:
        return caller_lambda(event, context)
    except Exception as e:
        print('error occured',e.__class__)
"""

